# the name of the specification

A brief description of the specification

## Goals

- goal
- goal

## Milestones

- [ ] milestone
- [ ] milestone

## Details

Add code snippets and/or a more in-depth description of the implementation details

## References

 - [name](href)
